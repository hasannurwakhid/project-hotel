console.log("Hello from TypeScript");
