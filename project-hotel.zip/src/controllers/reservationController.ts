import { Request, Response } from "express";
import { Reservation, Payment, Room, RoomType } from "../models";
import { v4 as uuidv4 } from "uuid";
import { Op } from "sequelize";

export const createReservation = async (req: Request, res: Response) => {
  try {
    const { roomId, checkInDate, checkOutDate, totalAmount, initialPayment } =
      req.body;

    const reservation = await Reservation.create({
      id: uuidv4(),
      roomId,
      checkInDate,
      checkOutDate,
      totalAmount,
    });

    if (initialPayment && initialPayment > 0) {
      await Payment.create({
        id: uuidv4(),
        reservationId: reservation.id,
        amount: initialPayment,
        paidAt: new Date(),
      });
    }

    res.status(201).json({ message: "Reservation created", reservation });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error creating reservation" });
  }
};

export const getReservationsByDate = async (req: Request, res: Response) => {
  const { startDate, endDate } = req.query;

  if (!startDate || !endDate) {
    return res
      .status(400)
      .json({ message: "startDate and endDate are required" });
  }

  try {
    const reservations = await Reservation.findAll({
      where: {
        [Op.or]: [
          {
            checkInDate: {
              [Op.between]: [startDate, endDate],
            },
          },
          {
            checkOutDate: {
              [Op.between]: [startDate, endDate],
            },
          },
          {
            checkInDate: {
              [Op.lte]: startDate,
            },
            checkOutDate: {
              [Op.gte]: endDate,
            },
          },
        ],
      },
      include: [
        {
          model: Room,
          include: [RoomType],
        },
        {
          model: Payment,
        },
      ],
    });

    const result = reservations.map((resv) => {
      const totalPaid =
        resv.Payments?.reduce((sum, p) => sum + p.amount, 0) || 0;
      const outstanding = resv.totalAmount - totalPaid;

      return {
        id: resv.id,
        checkInDate: resv.checkInDate,
        checkOutDate: resv.checkOutDate,
        totalAmount: resv.totalAmount,
        totalPaid,
        outstanding,
        room: {
          roomNumber: resv.Room?.roomNumber,
          roomType: resv.Room?.RoomType?.name,
        },
      };
    });

    return res.json(result);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Server error" });
  }
};
